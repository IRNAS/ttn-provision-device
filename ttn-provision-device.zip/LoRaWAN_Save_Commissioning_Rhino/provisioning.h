#define ABP

#define DTC_VALUE 4

#define ADS_CALIB_VALUE 1.4481

const char *devAddr = "2601132C";

const char *nwkSKey = "18A7E5F3538B5A18969E8F8DB001845B";

const char *appSKey = "97F9A3A0B7D367E43F22C5F0B57A25EE";

